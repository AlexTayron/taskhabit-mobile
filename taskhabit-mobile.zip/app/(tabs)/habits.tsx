import Habits from '../../components/pages/Habits';

export default Habits;