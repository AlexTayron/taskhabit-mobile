 import Profile from '../../components/pages/Profile';

export default Profile;