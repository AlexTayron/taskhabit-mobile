import Settings from '../../components/pages/Settings';

export default Settings; 