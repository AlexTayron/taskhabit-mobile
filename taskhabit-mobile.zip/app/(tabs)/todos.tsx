import Todos from '../../components/pages/Todos';

export default Todos; 